"""Add the accepted opening-only Water Sword equip guard to Steam Visuals.

The input project already contains the corrected RC4 record ordering.  This
script changes only Prince frame record 66038DE7 in its twelve providers and
keeps every other record byte-for-byte identical.
"""
from pathlib import Path
import copy
import hashlib
import json
import shutil
import struct
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SOURCE = ROOT / "work/release-prep/edition-builds/Steam-Visuals/project"
TARGET = HERE / "Steam-Clean/project"

sys.path.insert(0, str(ROOT / "work/jtmod-conversion"))
from rewrite import Code, call, emit, glob, kw, lit, native, splice, validate_nodes, wow_records


def guard():
    code = Code()
    emit(code, native(0x1FE0)); code.jump("end")
    emit(code, native(0x1F5F), lit(0x9000009F), kw(0x8A1)); code.jump("end")
    emit(code, glob(0x998, 0x28), kw(0x89F)); code.jump("end")
    emit(code, glob(0x7EC), lit(1031), kw(0x8A1)); code.jump("end")
    call(code, 0x500F, value=True); emit(code, lit(0), kw(0x8A4)); code.jump("end")
    emit(code, lit(0x3300089E, 0x28)); code.jump("end")
    call(code, 0x4FC1, args=([lit(0x3300089E, 0x28)],))
    code.label("end")
    return code.finish()


def frame(key, payload):
    return struct.pack("<III", len(payload), 0xEEFFC099, key) + payload


def main():
    if TARGET.parent.exists():
        raise SystemExit(f"Refusing to overwrite {TARGET.parent}")
    (TARGET / "assets").mkdir(parents=True)
    spec = json.loads((SOURCE / "project.json").read_text(encoding="utf-8"))
    spec = copy.deepcopy(spec)
    proof = []
    changed = 0
    for operation in spec["operations"]:
        source_name = operation["params"]["source"].split(":", 1)[1]
        raw = (SOURCE / "assets" / source_name).read_bytes()
        records = []
        world_changed = False
        before_hash = None
        after_hash = None
        for _, key, payload in wow_records.records(raw):
            if key == 0x66038DE7:
                before_hash = hashlib.sha256(payload).hexdigest()
                payload = splice(payload, 8, guard())
                validate_nodes(payload)
                after_hash = hashlib.sha256(payload).hexdigest()
                world_changed = True
                changed += 1
            records.append(frame(key, payload))
        result = b"".join(records)
        digest = hashlib.sha256(result).hexdigest()
        (TARGET / "assets" / digest).write_bytes(result)
        operation["params"]["source"] = "asset:" + digest
        if world_changed:
            proof.append({
                "world": f"{int(operation['target']['entry_key'], 16):08X}",
                "record": "66038DE7",
                "beforeSha256": before_hash,
                "afterSha256": after_hash,
                "allOtherRecordsUnchanged": True,
            })
    if changed != 12:
        raise RuntimeError(f"Expected 12 Prince frame providers, found {changed}")
    spec["name"] = "WW Prince and Water Sword - Steam Clean Start"
    spec["description"] = (
        "Steam edition with the Warrior Within Prince and a Water Sword equipped "
        "from a clean New Game. Requires PoP Mod Manager large-asset support and "
        "the included reversible Steam interpreter patch."
    )
    spec["modified"] = "2026-10-29T00:00:00Z"
    (TARGET / "project.json").write_text(json.dumps(spec, indent=2) + "\n", encoding="utf-8")
    (HERE / "steam-opening-proof.json").write_text(json.dumps({
        "status": "STATIC_PASS",
        "providers": changed,
        "record": "66038DE7",
        "scope": "opening-only equip guard; all other candidate records preserved",
        "worlds": proof,
    }, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"project": str(TARGET), "providers": changed}))


if __name__ == "__main__":
    main()

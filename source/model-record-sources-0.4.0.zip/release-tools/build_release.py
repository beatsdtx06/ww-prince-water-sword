"""Build and verify the 0.4.0 Steam/OpenJade clean-start packages."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TOOLS = ROOT / "work/toolchain/build"
BASE = Path(r"D:\SteamLibrary\steamapps\common\Prince of Persia Two Thrones\pop3.bf")
BASE_SHA256 = "00134ea93ccf27f29ede40d3521439ca8f8c0d38bc02fdfd0d18042e7929b600"
OUT = HERE / "output"

sys.path.insert(0, str(ROOT / "Source Code/Reproducible Build/pipeline/toolchain"))
sys.path.insert(0, str(ROOT / "work/toolchain"))
from annotate_jtmod_keys import annotate
from bf_index import read_index


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run(args, label):
    process = subprocess.run([str(value) for value in args], capture_output=True, text=True)
    text = process.stdout + process.stderr
    (HERE / f"{label}.log").write_text(text, encoding="utf-8")
    if process.returncode:
        raise RuntimeError(f"{label} failed\n{text}")
    print(label + " PASS", flush=True)


def archive_digest(path):
    stream, _, entries, _ = read_index(path)
    result = {}
    with stream:
        for entry in entries:
            if entry["key"] == 0xFFFFFFFF or entry["pos"] == 0xFFFFFFFF or not entry["name"]:
                continue
            stream.seek(entry["pos"])
            size = int.from_bytes(stream.read(4), "little")
            data = stream.read(size - 4)
            result[entry["key"]] = (entry["name"], size, hashlib.sha256(data).hexdigest())
    return result


def export_package(project, raw, final, title, description, minted_keys):
    run([
        TOOLS / "project_cli.exe", project, BASE, "-",
        "--export-jtmod", raw,
        "--jtmod-title", title,
        "--jtmod-author", "beatsdtx06",
        "--jtmod-version", "0.4.0",
        "--jtmod-description", description,
        "--jtmod-created", "2026-10-29T00:00:00Z",
    ], final.stem + "-export")
    data, _, discovered = annotate(raw.read_bytes(), minted_keys)
    if set(discovered) != set(minted_keys):
        raise RuntimeError("Minted-key annotation mismatch")
    final.write_bytes(data)
    run([TOOLS / "popmm.exe", "verify", BASE, final], final.stem + "-verify")


def main():
    if sha(BASE) != BASE_SHA256:
        raise RuntimeError("Stock pop3.bf mismatch")
    if OUT.exists():
        raise RuntimeError(f"Refusing to overwrite {OUT}")
    OUT.mkdir()

    steam_recipe = json.loads((ROOT / "Publication/ww-prince-water-sword/source/Steam-Visuals/delta-recipe.json").read_text())
    openjade_recipe = json.loads((ROOT / "Publication/ww-prince-water-sword/source/OpenJade-Full/delta-recipe.json").read_text())
    steam = OUT / "WW-Prince-Water-Sword-Steam-Clean-Start-0.4.0.jtmod"
    openjade = OUT / "WW-Prince-Water-Sword-OpenJade-Clean-Start-0.4.0.jtmod"
    export_package(
        HERE / "Steam-Clean/project", HERE / "steam.raw.jtmod", steam,
        "WW Prince and Water Sword - Steam Clean Start",
        "Steam edition with the Warrior Within Prince and Water Sword equipped from New Game. Requires PoP Mod Manager large assets and the included reversible Steam interpreter patch.",
        steam_recipe["mintedKeys"],
    )
    export_package(
        ROOT / "work/release-prep/opening-project-v2", HERE / "openjade.raw.jtmod", openjade,
        "WW Prince and Water Sword - OpenJade Clean Start",
        "OpenJade 0.4.1 edition with the Warrior Within Prince and persistent Water Sword equipped from New Game, enhanced damage and boss-only blue aura.",
        openjade_recipe["mintedKeys"],
    )

    steam_archive = HERE / "steam-clean-applied.bf"
    openjade_archive = HERE / "openjade-clean-applied.bf"
    run([TOOLS / "popmm.exe", "apply", BASE, steam_archive, steam], "steam-apply")
    run([TOOLS / "popmm.exe", "apply", BASE, openjade_archive, openjade], "openjade-apply")

    stock = archive_digest(BASE)
    steam_result = archive_digest(steam_archive)
    openjade_result = archive_digest(openjade_archive)
    if stock.keys() != steam_result.keys() or stock.keys() != openjade_result.keys():
        raise RuntimeError("Archive entry set changed")
    steam_changed = sorted(key for key in stock if stock[key] != steam_result[key])
    openjade_changed = sorted(key for key in stock if stock[key] != openjade_result[key])
    if len(steam_changed) != 33 or 0xFC000002 not in steam_changed:
        raise RuntimeError(f"Unexpected Steam scope: {len(steam_changed)} entries")
    if len(openjade_changed) != 62 or 0xFC000002 not in openjade_changed:
        raise RuntimeError(f"Unexpected OpenJade scope: {len(openjade_changed)} entries")

    reference = Path(r"C:\Users\alaa\Documents\Codex\Mods\Prince of Persia The Two Thrones\Compatibility Tests\OpenJade041\pop3.bf")
    reference_match = reference.is_file() and sha(reference) == sha(openjade_archive)
    report = {
        "status": "STATIC_AND_PACKAGE_PASS",
        "baseSha256": BASE_SHA256,
        "steam": {
            "file": steam.name,
            "bytes": steam.stat().st_size,
            "sha256": sha(steam),
            "appliedArchiveSha256": sha(steam_archive),
            "changedEntries": [f"{key:08X}" for key in steam_changed],
            "openingGuardProviders": 12,
            "runtimeRequirement": "PoP Mod Manager large assets plus guarded interpreter patch",
        },
        "openjade": {
            "file": openjade.name,
            "bytes": openjade.stat().st_size,
            "sha256": sha(openjade),
            "appliedArchiveSha256": sha(openjade_archive),
            "changedEntries": [f"{key:08X}" for key in openjade_changed],
            "matchesPreviouslyAppliedOpeningCandidate": reference_match,
        },
        "limits": [
            "Package and archive verification is current.",
            "The opening Water Sword behavior is inherited from the previously observed clean-start candidate.",
            "No new full-campaign replay was performed in this build step.",
        ],
    }
    (OUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

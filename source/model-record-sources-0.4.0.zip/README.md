# 0.4.0 maintenance source

`Steam-Visuals` and `OpenJade-Full` preserve the compact record-level sources, readable scripts and deterministic reconstruction tools from the prior release line.

`release-tools/make_steam_clean_project.py` is the 0.4.0 transformation that inserts the guarded opening Water Sword grant into all 12 Steam Prince frame providers without changing other records. Its proof is in `steam-opening-proof.json`. `build_release.py` records the exact export, annotation, verification and applied-archive checks used for 0.4.0. The paths in that script reflect the maintainer's local toolchain and must be adjusted for another checkout.

`Install-Steam-Water-Sword.ps1` is the complete source for the reversible Steam interpreter patch. `verification.json` records the final package and applied-archive hashes. `project-metadata` preserves the final Jade Toolkit project manifests; raw game-derived project assets are intentionally not redistributed in this repository source archive.

No game executable or complete game archive is included.

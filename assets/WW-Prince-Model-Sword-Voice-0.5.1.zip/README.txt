WW PRINCE - MODEL, WATER SWORD & VOICE 0.5.1
OPENJADE ONLY - NOT ORIGINAL STEAM ENGINE

Requires an existing OpenJade 0.5.1 game with supported English audio and PoP Mod Manager 2.1.2.
1. Extract this ZIP.
2. Import WW-Prince-Model-Sword-Voice-0.5.1.jtmod into Mod Manager for OpenJade The Two Thrones.
3. Disable older WW Prince/model/sword/voice packages. Enable this one and Apply.
4. Launch the game.

No CMD, PowerShell, installer, executable patch, or extra setup.
Includes WW Prince model, clean-start Water Sword, enhanced damage, boss-only blue aura,
and 93 approved English AI-converted spoken lines. Voice coverage is partial.
Back up saves. Other language banks and overlapping sound/model mods are not supported.
Use Mod Manager Restore original to uninstall; its backups must be retained.
If you previously RAN the old 0.5.0 helper, see the repository recovery guide before upgrading.

https://github.com/beatsdtx06/ww-prince-water-sword

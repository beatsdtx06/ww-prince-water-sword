"""Assemble maintained JTMod v2 delta records. No archive parser or LZO decoder.

The user's stock archive is read only to validate its size and SHA-256.
Offsets in the recipe are record indices understood by PoP Mod Manager.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def u32(value):
    return struct.pack('<I', value)


def blob(value):
    if isinstance(value, str):
        value = value.encode('utf-8')
    return u32(len(value)) + value


def build(source, base, out):
    recipe = json.loads((source / 'delta-recipe.json').read_text())
    if base.stat().st_size != recipe['baseSize'] or digest(base) != recipe['baseSha256']:
        raise ValueError('Unsupported stock archive; nothing written')
    if out.exists() or source == out or source in out.parents or out in source.parents or out in base.parents:
        raise ValueError('Output must be a separate new directory')
    records = {}
    for world in recipe['worlds']:
        end = 0
        for hunk in world['hunks']:
            if not end <= hunk['start'] <= hunk['end'] <= world['recordCount']:
                raise ValueError('Invalid or overlapping delta range')
            end = hunk['end']
            for h in hunk['records']:
                if len(h) != 64 or any(c not in '0123456789abcdef' for c in h):
                    raise ValueError('Invalid record filename')
                data = (source / 'delta-records' / h).read_bytes()
                if hashlib.sha256(data).hexdigest() != h:
                    raise ValueError('Record hash mismatch')
                if len(data) < 12 or struct.unpack_from('<I', data)[0] != len(data)-12 or struct.unpack_from('<I', data,4)[0] != 0xEEFFC099:
                    raise ValueError('Malformed record')
                records[h] = data
    core = b'JADEJTM1' + u32(2) + u32(0) + blob(recipe['game']) + blob(recipe['archive'])
    core += struct.pack('<Q',recipe['baseSize']) + bytes.fromhex(recipe['baseSha256'])
    core += b''.join(blob(value) for value in recipe['metadata']) + blob(b'')
    core += u32(len(recipe['mintedKeys'])) + b''.join(u32(k) for k in recipe['mintedKeys'])
    core += u32(len(recipe['worlds']))
    for world in recipe['worlds']:
        core += struct.pack('<IBII',world['key'],1,world['recordCount'],len(world['hunks']))
        for hunk in world['hunks']:
            core += struct.pack('<III',hunk['start'],hunk['end'],len(hunk['records']))
            core += b''.join(blob(records[h]) for h in hunk['records'])
    package = core + b'JTMHASH1' + hashlib.sha256(b'jtmod-integrity-v1'+core).digest()
    actual = hashlib.sha256(package).hexdigest()
    if actual != recipe['expectedPackageSha256']:
        raise ValueError('Package differs from accepted recipe; nothing written')
    filename = recipe['filename']
    if Path(filename).name != filename or not filename.endswith('.jtmod'):
        raise ValueError('Invalid package filename')
    out.mkdir(parents=True)
    (out / filename).write_bytes(package)
    report = {'sha256':actual,'package':filename,'worlds':len(recipe['worlds']),'status':'IDENTICAL_TO_VERIFIED_PACKAGE'}
    (out / 'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--base',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args = parser.parse_args()
    build(args.source.resolve(),args.base.resolve(),args.out.resolve())

"""Reviewable native damage/aura constructors. Canonical final records are in records/."""
import struct
from native_code import Code,node,object_allowlist,PRIMARY_KEYS
from script_listing import nodes,listing
JUMPS={0x8FC,0x8FD,0x8FE,0x900,0x901,0x902,0x903}
AURA_SET=126
TICK_PROC=0x6FFE
BOSS_PROC=0x6FFD
BOSS_IDS={'klompa':0x6FF9,'mahasti':0x6FFA,'twins':0x6FFB,'vizier':0x6FFC}
BOSS_CACHE=0x1E4C
BOSSES=[
    # named actor(s), model, existing common function, exact arena, kind
    ((0x0900190E,),0x090018EE,0x090018CD,0x16005BE5,'klompa'),
    ((0x6603A4BD,),0x6603A543,0x6603A529,0xDE001EE8,'mahasti'),
    ((0x09002769,0x09002984),0x09002AA5,0x09002A91,0xDE0030F5,'twins'),
    ((0x6C0006DA,),0x6C00074A,0x6C00073E,0x1600B2F1,'vizier'),
]

def emit(c,*ns):
    for n in ns:c.emit(*n)
def lit(v,t=0x21):return (v,t,1)
def local(v,t=0x21):return (v,t,5)
def glob(v,t=0x21):return (v,t,0x14)
def kw(i):return (0,i,2)
def native(i):return (0,i,3)
def field(i):return (0,i,4)
def ctx(c,expr):emit(c,*expr,kw(0x806))
def call(c,i,context=None,args=(),value=False):
    if context is not None:ctx(c,context)
    c.emit(0,i,0x1B)
    for expr in args:emit(c,*expr,kw(0x836))
    c.emit(0,i,0x10)
    if value:emit(c,kw(0x837))
def fbits(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def proc_start(c,i,params=(),last_local=None):
    c.emit(0,i,0x1C);c.emit(0,0,0x11)
    if last_local is not None:emit(c,local(last_local))
    for off,typ in reversed(params):emit(c,local(off,typ),kw(0x837),kw(0x898))
    c.emit(0,0,0x12)
def ret(c,v):emit(c,lit(v),kw(0x836),kw(0x834))

def splice(data,at,extra):
    size=struct.unpack_from('<I',data,4)[0];tail=data[8+size:]
    assert len(tail)==4+struct.unpack_from('<I',tail)[0]
    assert at%8==0 and 8<=at<8+size and len(extra)%8==0
    out=bytearray(data[:at]+extra+data[at:])
    struct.pack_into('<I',out,4,size+len(extra))
    for off,v,i,f,t in nodes(data):
        if t==2 and i in JUMPS:
            target=off+struct.unpack('<i',struct.pack('<I',v))[0]*8
            assert 8<=target<8+size and target%8==0
            newoff=off+(len(extra) if off>=at else 0)
            # Incoming branches to the insertion execute the new guard too.
            newtarget=target+(len(extra) if target>at else 0)
            struct.pack_into('<i',out,newoff,(newtarget-newoff)//8)
    validate_nodes(out)
    return bytes(out)

def validate_nodes(d):
    ns=list(nodes(d));end=8+struct.unpack_from('<I',d,4)[0]
    assert ns[-1][4]==0x1F
    for o,v,i,f,t in ns:
        assert f==0
        if t==2 and i in JUMPS:
            target=o+struct.unpack('<i',struct.pack('<I',v))[0]*8
            assert 8<=target<end and target%8==0,(hex(o),hex(target))

def append_proc(data,extra):
    ns=list(nodes(data));assert ns[-1][4]==0x1F
    return splice(data,ns[-1][0],extra)

def damage_guard():
    c=Code();msg=[local(4,0x29)]
    emit(c,*msg,field(0x204),lit(1),kw(0x8A1));c.jump('end')
    emit(c,*msg,field(0x207),lit(0,0x22),kw(0x8A4));c.jump('end')
    emit(c,*msg,field(0x203),lit(0x66038E35,0x28),kw(0x8B6));c.jump('end')
    emit(c,*msg,field(0x209));c.jump('end')
    object_allowlist(c,msg+[field(0x209)]);c.jump('end')
    emit(c,*msg,field(0x209))
    call(c,0x4FFF,[lit(0x66038E35,0x28)],value=True)
    emit(c,kw(0x8B6));c.jump('end')
    # These bosses own explicit damage replacements and phase thresholds.
    for model in (0x6603A543,0x6C00074A):
        emit(c,lit(model,0x2A));ctx(c,[local(0,0x28)]);emit(c,native(0x178C))
        c.jump('next'+hex(model));c.jump('end',0x8FC);c.label('next'+hex(model))
    # Increase only the private dispatch copy. Native block/hit rejection,
    # dismemberment/death handling, and Klompa/Twins minimum-HP clamps remain.
    emit(c,*msg,field(0x207),lit(fbits(1000000.0),0x22),kw(0x898))
    c.label('end');return c.finish()


def boss_proc(kind,arena):
    c=Code();proc_start(c,BOSS_IDS[kind],((0,0x21),),last_local=0) # previous effect active
    emit(c,native(0x1FE0));c.jump('off')
    emit(c,native(0x1FB4),lit(0x400000),kw(0x8AF),lit(0),kw(0x8A1));c.jump('off')
    hp=0xD8 if kind=='vizier' else 0xE8
    # Retain a confirmed effect through a visible finishing animation at HP0.
    emit(c,local(0));c.jump('initial')
    emit(c,native(0x1FB4),lit(0x200000),kw(0x8AF),lit(0),kw(0x8A1));c.jump('initial')
    c.jump('on',0x8FC)
    c.label('initial')
    emit(c,glob(hp),lit(0),kw(0x8A4));c.jump('off')
    if kind=='vizier':
        emit(c,glob(0x1D8),lit(1),kw(0x8A1));c.jump('off')
        for phase in (1,2,3):
            emit(c,glob(0xAC,0x22),lit(phase),kw(0x8A1));c.jump('phase'+str(phase))
            c.jump('on',0x8FC);c.label('phase'+str(phase))
        c.jump('off',0x8FC)
    else:
        emit(c,glob(0x298),lit(4),kw(0x8A1));c.jump('off')
        # Visible life4 actors cover native intro scenes as well as combat.
        emit(c,native(0x1FB4),lit(0x200000),kw(0x8AF),lit(0),kw(0x8A1));c.jump('off')
    c.label('on');ret(c,1);c.jump('finish',0x8FC)
    c.label('off');ret(c,0)
    c.label('finish');c.emit(0,0,0x1D)
    return c.finish()

def aura_proc():
    c=Code();proc_start(c,TICK_PROC,last_local=28)
    # Locals: right handle0, previously-active4, desired8, world12.
    emit(c,local(0,0x28),glob(0x998,0x28),kw(0x898))
    emit(c,local(8),lit(0),kw(0x898))
    emit(c,local(0,0x28));c.jump('cleanup')
    object_allowlist(c,[local(0,0x28)]);c.jump('cleanup')
    emit(c,local(4),lit(AURA_SET));ctx(c,[local(0,0x28)]);emit(c,native(0x3E02),kw(0x898))
    # Native Prince health getter (same human/Dark model); never change health.
    call(c,0x500F,value=True);emit(c,lit(0),kw(0x8A4));c.jump('cleanup')
    for actors,model,record,arena,kind in BOSSES:
        # Boss scripts publish their live clone handle. The legacy world-count
        # API is absent in TTT; never enumerate beyond an unverified bound.
        end='next_cached_'+kind
        # TTT 1F5F reads the current player object's world key (+0x4D28).
        # A streamed boss can already run life4 while the Prince is elsewhere.
        emit(c,native(0x1F5F),lit(arena),kw(0x8A1));c.jump(end)
        emit(c,local(28,0x28),lit(list(BOSS_IDS).index(kind)),(BOSS_CACHE,0x28,0x15),kw(0x898))
        emit(c,local(28,0x28));c.jump(end)
        ctx(c,[local(28,0x28)]);emit(c,native(0x1FE0));c.jump(end)
        emit(c,lit(model,0x2A));ctx(c,[local(28,0x28)]);emit(c,native(0x178C));c.jump(end)
        call(c,BOSS_IDS[kind],[local(28,0x28)],([local(4)],),value=True);c.jump(end)
        emit(c,local(8),lit(1),kw(0x898));c.jump('cleanup',0x8FC)
        c.label(end)
        c.label('next_'+kind)
    c.label('cleanup')
    for key in PRIMARY_KEYS:
        nxt='weapon_'+hex(key);off='off_'+hex(key)
        emit(c,lit(key,0x28));c.jump(nxt)
        emit(c,lit(key,0x28),local(0,0x28),kw(0x8B6));c.jump(off)
        emit(c,local(8));c.jump(off)
        emit(c,lit(AURA_SET));ctx(c,[lit(key,0x28)]);emit(c,native(0x3E02));c.jump('start_'+hex(key))
        c.jump(nxt,0x8FC);c.label('start_'+hex(key))
        emit(c,lit(AURA_SET));ctx(c,[lit(key,0x28)]);emit(c,native(0x3DFD));c.jump(nxt,0x8FC)
        c.label(off)
        emit(c,lit(AURA_SET));ctx(c,[lit(key,0x28)]);emit(c,native(0x3E02));c.jump(nxt)
        emit(c,lit(AURA_SET));ctx(c,[lit(key,0x28)]);emit(c,native(0x3E01))
        c.label(nxt)
    c.emit(0,0,0x1D);return c.finish()

def cache_setter():
    c=Code();proc_start(c,BOSS_PROC,((0,0x21),(4,0x28)),last_local=4)
    emit(c,local(0),lit(0),kw(0x8A2));c.jump('end')
    emit(c,local(0),lit(4),kw(0x8A5));c.jump('end')
    emit(c,local(0),(BOSS_CACHE,0x28,0x15),local(4,0x28),kw(0x898))
    c.label('end');c.emit(0,0,0x1D);return c.finish()

def boss_publish(kind,arena):
    c=Code()
    emit(c,native(0x1FE0));c.jump('end')
    emit(c,native(0x1FB4),lit(0x400000),kw(0x8AF),lit(0),kw(0x8A1));c.jump('end')
    # Preserve self before selecting the Prince as the procedure receiver.
    emit(c,local(0x400,0x28),native(0x1FB0),kw(0x898))
    call(c,BOSS_PROC,[lit(0x66038E35,0x28)],([lit(list(BOSS_IDS).index(kind))],[local(0x400,0x28)]))
    c.label('end');return c.finish()

def add_cache_vars(d):
    table_size=struct.unpack_from('<I',d,4)[0];table_end=8+table_size
    hashes=struct.unpack_from('<I',d,table_end)[0];assert table_size==hashes*12
    init_at=table_end+4+hashes*4;size=struct.unpack_from('<I',d,init_at)[0]
    assert size==BOSS_CACHE
    entry=struct.pack('<IIHH',BOSS_CACHE,0x40000004,0x28,1)
    return (d[:4]+struct.pack('<I',table_size+12)+d[8:table_end]+entry+
        struct.pack('<I',hashes+1)+d[table_end+4:init_at]+struct.pack('<I',0xF1A2CACE)+
        struct.pack('<I',size+20)+d[init_at+4:init_at+4+size]+struct.pack('<5I',4,0,0,0,0)+d[init_at+4+size:])



def add_aura_modifier(d,host):
    signature=struct.pack('<III',47,0x1000000,2)
    hs=host.index(signature)
    assert struct.unpack_from('<4I',host,hs+12)==(2,0,0,1)
    spatial=host[hs+28:hs+108]
    newset=struct.pack('<5I',AURA_SET,0,2,0,0)
    # Keep spatial generators alive until the boss controller stops the set.
    # Zero duration repeatedly starts/stops them before particles are visible.
    newrefs=struct.pack('<IffIff',0,0.,3600.,1,0.,3600.)
    if signature in d:
        s=d.index(signature);assert d.count(signature)==1
        assert struct.unpack_from('<4I',d,s+12)==(0,0,1,1)
        extra=d[s+28:s+81] # TTT extra emitter: 36 + key4 + byte1 + floats12
        oldset=d[s+81:s+101];assert struct.unpack('<5I',oldset)==(0,0,0,1,0)
        oldrefs=d[s+101:s+113];assert len(oldrefs)==12
        assert d[s+113:s+117]==b'\xff'*4
        merged=signature+struct.pack('<4I',2,0,1,2)+spatial+extra+oldset+newset+oldrefs+newrefs
        return d[:s]+merged+d[s+113:]
    assert d[-8:-4]==b'\xff'*4
    return d[:-8]+signature+struct.pack('<4I',2,0,0,1)+spatial+newset+newrefs+d[-8:]


"""Split a decompressed WW world blob (*.dec) into its Jade records.

Record layout (verified on a packed world archive): [u32 size][u32 0xEEFFC099][u32 key][size bytes]

usage: python -I wow_records.py <file.dec> [outdir]   -> prints a table; with outdir, writes <key>.<type> files
"""
import collections
import os
import re
import struct
import sys

MARK = 0xEEFFC099


def records(d):
    o = 0
    while o + 12 <= len(d):
        size, mark, key = struct.unpack_from("<3I", d, o)
        if mark != MARK:
            raise ValueError(f"bad marker at {o:#x}: {mark:#x}")
        yield o, key, d[o + 12:o + 12 + size]
        o += 12 + size


def kind(b):
    if len(b) >= 4 and re.fullmatch(rb"\.[a-z0-9]{3}", b[:4]):
        return b[1:4].decode()
    if len(b) >= 8 and re.fullmatch(rb"\.[a-z0-9]{3}", b[4:8]):
        return b[5:8].decode() + "@4"
    return "bin" if b else "empty"


def names(b):
    return [m.decode("latin-1") for m in re.findall(rb"[A-Za-z_][A-Za-z0-9_ .\-]{5,}", b)][:4]


def main():
    d = open(sys.argv[1], "rb").read()
    out = sys.argv[2] if len(sys.argv) > 2 else None
    if out:
        os.makedirs(out, exist_ok=True)
    cnt = collections.Counter()
    for o, key, b in records(d):
        k = kind(b)
        cnt[k] += 1
        print(f"{o:08x} {key:08x} {len(b):8d} {k:8s} {names(b)}")
        if out:
            open(os.path.join(out, f"{key:08x}.{k.replace('@4', '')}"), "wb").write(b)
    print(dict(cnt), file=sys.stderr)


if __name__ == "__main__":
    main()

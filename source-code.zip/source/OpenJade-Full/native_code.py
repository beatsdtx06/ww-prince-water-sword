"""Pure native Jade bytecode construction helpers; no process access."""
import struct
def check(ok, message):
    if not ok:
        raise ValueError(message)

def node(value, ident, kind):
    return struct.pack('<IHBB', value & 0xFFFFFFFF, ident, 0, kind)

PRIMARY_KEYS=(0x3300089E,0x9700001A,0x330008A0)
class Code:
    def __init__(self): self.nodes, self.labels = [], {}
    def emit(self, value, ident, kind): self.nodes.append((value, ident, kind))
    def label(self, name):
        check(name not in self.labels, 'Duplicate label'); self.labels[name] = len(self.nodes)
    def jump(self, name, ident=0x900): self.emit(name, ident, 2)
    def finish(self):
        return b''.join(node(self.labels[v]-i if isinstance(v, str) else v, k, t)
                        for i, (v, k, t) in enumerate(self.nodes))

def object_allowlist(code, expression):
    """Leave one boolean using native consuming branches, not parser OR nodes.

    Raw keyword804 is AI_dum in OpenJade: it advances without reducing the
    value stack. Native short-circuit branches must combine these comparisons.
    """
    prefix = f'allowlist_{len(code.nodes)}'
    done = prefix + '_done'
    for i, key in enumerate(PRIMARY_KEYS):
        for n in expression: code.emit(*n)
        code.emit(key, 0x28, 1)
        code.emit(0, 0x8B6, 2)
        if i + 1 < len(PRIMARY_KEYS):
            next_key = f'{prefix}_next_{i}'
            code.jump(next_key)  #900 consumes the comparison; zero tries next key.
            code.emit(1, 0x21, 1)
            code.jump(done, 0x8FC)  #The true branch leaves exactly one result.
            code.label(next_key)
    code.label(done)  #The final comparison itself supplies the false/true result.

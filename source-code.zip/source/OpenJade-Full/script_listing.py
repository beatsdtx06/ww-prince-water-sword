import struct
def nodes(data):
    size=struct.unpack_from('<I',data,4)[0]
    assert size%8==0 and 8+size+4<=len(data)
    for off in range(8,8+size,8):
        yield (off,*struct.unpack_from('<IHBB',data,off))

def listing(data):
    lines=[]
    for off,v,i,f,t in nodes(data):
        extra=''
        if t==2 and i in (0x8FC,0x8FD,0x8FE,0x900,0x901,0x902,0x903):
            extra=f' ->{off+struct.unpack("<i",struct.pack("<I",v))[0]*8:X}'
        if t==1 and i==0x22: extra=f' float={struct.unpack("<f",struct.pack("<I",v))[0]}'
        lines.append(f'{off:05X} {v:08X} {i:04X} {f:02X} {t:02X}{extra}')
    return '\n'.join(lines)+'\n'

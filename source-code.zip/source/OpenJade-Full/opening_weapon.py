"""Opening-only equip guard, inserted into Prince frame at offset 8.
Final canonical bytecode is pinned by manifest.json.
"""
from native_behavior import *
def guard():
    c=Code()
    emit(c,native(0x1FE0));c.jump('end')
    emit(c,native(0x1F5F),lit(0x9000009F),kw(0x8A1));c.jump('end')
    emit(c,glob(0x998,0x28),kw(0x89F));c.jump('end')
    emit(c,glob(0x7EC),lit(1031),kw(0x8A1));c.jump('end')
    call(c,0x500F,value=True);emit(c,lit(0),kw(0x8A4));c.jump('end')
    emit(c,lit(0x3300089E,0x28));c.jump('end')
    call(c,0x4FC1,args=([lit(0x3300089E,0x28)],))
    c.label('end');return c.finish()
